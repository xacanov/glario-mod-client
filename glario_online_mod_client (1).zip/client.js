
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

const mods = {
  freecam: false,
  hatSwitch: false,
  fastPlace: false,
  weaponRadius: false
};

for (let mod in mods) {
  document.getElementById(mod).onchange = e => mods[mod] = e.target.checked;
}

document.addEventListener("keydown", e => {
  if (e.code === "KeyR") {
    socket.send(new Uint8Array([0x00]));
    console.log("Sent respawn");
  }
  if (e.code === "KeyF") mods.freecam = !mods.freecam;
  if (e.code === "KeyX") mods.hatSwitch = !mods.hatSwitch;
});

let players = [];
let myId = null;

const socket = new WebSocket("wss://game.glar.io");
socket.binaryType = "arraybuffer";

socket.onopen = () => {
  console.log("[WS] Connected");
  // Send dummy handshake if needed
};

socket.onmessage = (event) => {
  try {
    const view = new DataView(event.data);
    console.log("[WS] Received data len:", view.byteLength);
    // Actual decoding would depend on glar.io protocol
  } catch (e) {
    console.error("WS parse error:", e);
  }
};

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  // Render logic would go here
  requestAnimationFrame(draw);
}

draw();
